# Lock switch animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaroniker/pen/XxPNqY](https://codepen.io/aaroniker/pen/XxPNqY).

From https://dribbble.com/shots/5397118--Custom-Switch